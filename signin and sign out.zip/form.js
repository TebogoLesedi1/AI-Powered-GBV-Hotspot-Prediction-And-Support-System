import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Your Firebase config - from your photo
const firebaseConfig = {
  apiKey: "AIzaSyCWy5YATkAI1-kUhFy48ViurMlCcwvUHWY",
  authDomain: "ai-powered-gbv-prediction.firebaseapp.com",
  databaseURL: "https://ai-powered-gbv-prediction-default-rtdb.firebaseio.com",
  projectId: "ai-powered-gbv-prediction",
  storageBucket: "ai-powered-gbv-prediction.firebasestorage.app",
  messagingSenderId: "60413598655",
  appId: "1:60413598655:web:8b3e874a1399402432da",
  measurementId: "G-ES6F4VJCV1",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

document.addEventListener("DOMContentLoaded", () => {
  const loginBox = document.getElementById("login-box");
  const signupBox = document.getElementById("signup-box");

  document.getElementById("go-to-signup")?.addEventListener("click", (e) => {
    e.preventDefault();
    loginBox.classList.add("hidden");
    signupBox.classList.remove("hidden");
  });

  document.getElementById("go-to-login")?.addEventListener("click", (e) => {
    e.preventDefault();
    signupBox.classList.add("hidden");
    loginBox.classList.remove("hidden");
  });

  // SIGNUP
  document
    .getElementById("signup-form")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("signup-name").value;
      const email = document.getElementById("signup-email").value;
      const password = document.getElementById("signup-password").value;

      try {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          email,
          password,
        );
        await updateProfile(userCredential.user, { displayName: name });
        alert("✅ Account created! Welcome " + name);
        signupBox.classList.add("hidden");
        loginBox.classList.remove("hidden");
      } catch (error) {
        alert("Error: " + error.message);
      }
    });

  // LOGIN
  document
    .getElementById("login-form")
    .addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = document.getElementById("login-email").value;
      const password = document.getElementById("login-password").value;

      try {
        const userCredential = await signInWithEmailAndPassword(
          auth,
          email,
          password,
        );
        alert(
          "✅ Login success! Welcome " +
            (userCredential.user.displayName || userCredential.user.email),
        );
      } catch (error) {
        alert("❌ Login failed: " + error.message);
      }
    });
});
